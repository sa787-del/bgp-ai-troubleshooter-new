```python
import json
import logging
import os
from dataclasses import asdict
from pathlib import Path
from typing import Any, Literal

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from tools.device_client import FRRDeviceClient
from tools.bgp_state import BGPStateTool
from tools.bgp_neighbor import BGPNeighborTool
from tools.interface import InterfaceTool
from tools.tcp_port import TCPPortTool
from tools.config import ConfigTool
from tools.route_table import RouteTableTool
from tools.route_map import RouteMapTool
from rules_db.rules_db import RulesDB

log = logging.getLogger(__name__)

ROOT = Path(__file__).resolve().parents[1]
INVENTORY_PATH = Path(
    os.getenv(
        "DEVICE_INVENTORY_FILE",
        str(ROOT / "config" / "devices.json"),
    )
)

app = FastAPI(
    title="BGP AI Troubleshooter API",
    version="0.4.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        origin.strip()
        for origin in os.getenv(
            "CORS_ORIGINS",
            "http://localhost:5173,http://127.0.0.1:5173",
        ).split(",")
        if origin.strip()
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

rules_db = RulesDB()


class DeviceRequest(BaseModel):
    host: str = "127.0.0.1"
    device_port: int = Field(default=2221, ge=1, le=65535)


class BGPStateRequest(DeviceRequest):
    peer: str | None = None


class BGPNeighborRequest(DeviceRequest):
    peer: str = Field(min_length=1)


class InterfaceRequest(DeviceRequest):
    interface: str | None = None
    interface_name: str | None = None


class TCPCheckRequest(DeviceRequest):
    peer_ip: str = Field(min_length=1)
    port: int = Field(default=179, ge=1, le=65535)


class ConfigDiffRequest(DeviceRequest):
    pass


class RouteTableRequest(DeviceRequest):
    prefix: str | None = None


class RouteMapRequest(DeviceRequest):
    name: str | None = None


class AnalyzeRequest(DeviceRequest):
    question: str = Field(min_length=5, max_length=1000)
    peer: str = Field(min_length=1, max_length=255)
    mode: Literal["agent", "rules"] = "agent"
    use_ml: bool = True
    max_steps: int = Field(default=6, ge=1, le=10)


def load_devices() -> list[dict[str, Any]]:
    """Load and validate the central JSON device inventory."""
    if not INVENTORY_PATH.is_file():
        raise HTTPException(
            status_code=500,
            detail=f"Device inventory file not found: {INVENTORY_PATH}",
        )

    try:
        raw = json.loads(
            INVENTORY_PATH.read_text(encoding="utf-8")
        )
    except (OSError, json.JSONDecodeError) as exc:
        log.exception("Could not read device inventory")
        raise HTTPException(
            status_code=500,
            detail="Device inventory is unreadable or invalid JSON",
        ) from exc

    if not isinstance(raw, list):
        raise HTTPException(
            status_code=500,
            detail="Device inventory must be a JSON list",
        )

    required = ("id", "name", "host", "ip", "port")
    seen_ids = set()
    seen_targets = set()
    devices = []

    for index, item in enumerate(raw):
        if not isinstance(item, dict):
            raise HTTPException(
                status_code=500,
                detail=f"Inventory entry {index} must be an object",
            )

        missing = [key for key in required if key not in item]
        if missing:
            raise HTTPException(
                status_code=500,
                detail=(
                    f"Inventory entry {index} is missing: "
                    + ", ".join(missing)
                ),
            )

        device = dict(item)
        device_id = str(device["id"]).strip()
        name = str(device["name"]).strip()
        host = str(device["host"]).strip()

        try:
            port = int(device["port"])
        except (TypeError, ValueError) as exc:
            raise HTTPException(
                status_code=500,
                detail=f"Invalid SSH port for device {device_id}",
            ) from exc

        if (
            not device_id
            or not name
            or not host
            or not 1 <= port <= 65535
        ):
            raise HTTPException(
                status_code=500,
                detail=f"Invalid inventory entry at index {index}",
            )

        if device_id in seen_ids:
            raise HTTPException(
                status_code=500,
                detail=f"Duplicate device id: {device_id}",
            )

        target = (host, port)
        if target in seen_targets:
            raise HTTPException(
                status_code=500,
                detail=f"Duplicate SSH target: {host}:{port}",
            )

        seen_ids.add(device_id)
        seen_targets.add(target)

        device.update({
            "id": device_id,
            "name": name,
            "host": host,
            "port": port,
            "enabled": bool(device.get("enabled", True)),
        })
        device.setdefault(
            "peers",
            [device["peer"]] if device.get("peer") else [],
        )
        device.setdefault("platform", "FRR")
        devices.append(device)

    return [device for device in devices if device["enabled"]]


def public_device(device: dict[str, Any]) -> dict[str, Any]:
    """Expose dashboard fields, not internal configuration."""
    allowed = (
        "id", "name", "host", "ip", "port", "asn",
        "rid", "peer", "peers", "platform", "enabled",
    )
    return {
        key: device[key]
        for key in allowed
        if key in device
    }


def resolve_device(host: str, port: int) -> dict[str, Any]:
    """Reject targets that are not in the enabled inventory."""
    for device in load_devices():
        accepted_hosts = {
            device["host"],
            str(device.get("ip", "")),
        }

        if host in accepted_hosts and port == device["port"]:
            return device

    raise HTTPException(
        status_code=400,
        detail=(
            "Target host/port is not in the enabled device inventory. "
            "Update config/devices.json first."
        ),
    )


def make_tool(tool_class, device_port: int):
    """Create an independent client for every collection request."""
    client = FRRDeviceClient(
        username=os.getenv("FRR_SSH_USERNAME", "admin"),
        password=os.getenv("FRR_SSH_PASSWORD", "admin"),
        port=device_port,
        timeout=float(os.getenv("FRR_SSH_TIMEOUT", "8")),
    )
    return tool_class(device_client=client)


def run_tool(tool_class, req: DeviceRequest, *args):
    resolve_device(req.host, req.device_port)

    try:
        tool = make_tool(tool_class, req.device_port)
        return tool.run(req.host, *args).to_dict()
    except HTTPException:
        raise
    except Exception as exc:
        log.exception(
            "Tool execution failed: %s",
            tool_class.__name__,
        )
        raise HTTPException(
            status_code=502,
            detail=f"{tool_class.__name__} execution failed",
        ) from exc


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/devices")
def devices_endpoint():
    return {
        "devices": [
            public_device(device)
            for device in load_devices()
        ]
    }


@app.post("/tools/bgp/state")
def bgp_state(req: BGPStateRequest):
    return run_tool(BGPStateTool, req, req.peer)


@app.post("/tools/bgp/neighbor")
def bgp_neighbor(req: BGPNeighborRequest):
    return run_tool(BGPNeighborTool, req, req.peer)


@app.post("/tools/interface/detail")
def interface_detail(req: InterfaceRequest):
    interface = req.interface or req.interface_name
    return run_tool(InterfaceTool, req, interface)


@app.post("/tools/tcp/check")
def tcp_check(req: TCPCheckRequest):
    return run_tool(
        TCPPortTool,
        req,
        req.peer_ip,
        req.port,
    )


@app.post("/tools/config/diff")
def config_diff(req: ConfigDiffRequest):
    return run_tool(ConfigTool, req)


@app.post("/tools/route/table")
def route_table(req: RouteTableRequest):
    return run_tool(RouteTableTool, req, req.prefix)


@app.post("/tools/route/map")
def route_map(req: RouteMapRequest):
    return run_tool(RouteMapTool, req, req.name)


@app.post("/analyze")
def analyze(req: AnalyzeRequest):
    """
    Run an investigation against an enabled inventory device.

    The analyser uses the project's existing RestClient to call
    the API's collection and rules endpoints.
    """
    device = resolve_device(req.host, req.device_port)

    configured_peers = {
        str(value).strip()
        for value in (
            list(device.get("peers") or [])
            + ([device.get("peer")] if device.get("peer") else [])
        )
        if value
    }

    if configured_peers and req.peer not in configured_peers:
        raise HTTPException(
            status_code=400,
            detail="The selected peer is not configured for this device.",
        )

    try:
        # Import here so existing collection endpoints can start
        # independently of optional analyser dependencies.
        from analyzer.rest_client import RestClient
        from analyzer.agent import investigate
        from analyzer.rules_engine import diagnose

        # RestClient defaults to the local API. Override this when
        # the backend is hosted on another address.
        api_base = os.getenv(
            "ANALYZER_API_BASE",
            "http://127.0.0.1:8000",
        ).rstrip("/")
        client = RestClient(api_base)

        if req.mode == "agent":
            verdict = investigate(
                client=client,
                question=req.question.strip(),
                host=req.host,
                peer=req.peer,
                max_steps=req.max_steps,
                use_ml=req.use_ml,
            )
        else:
            verdict = diagnose(
                client=client,
                question=req.question.strip(),
                host=req.host,
                peer=req.peer,
                use_ml=req.use_ml,
                use_llm=False,
            )

        return {
            "success": True,
            "device": public_device(device),
            "diagnosis": asdict(verdict),
        }

    except HTTPException:
        raise
    except Exception as exc:
        log.exception("BGP analysis failed")
        raise HTTPException(
            status_code=502,
            detail=(
                "Analysis failed. Check analyser configuration, "
                "model availability, and backend logs."
            ),
        ) from exc


@app.get("/rules/intents")
def list_intents():
    return {"intents": rules_db.list_intents()}


@app.get("/rules/tools")
def list_tools():
    return {
        "tools": [
            tool.__dict__
            for tool in rules_db.list_tools()
        ]
    }


@app.get("/rules/catalog")
def catalog():
    return {
        "tools": [
            tool.__dict__
            for tool in rules_db.list_tools()
        ],
        "rules": [
            rule.__dict__
            for rule in rules_db.list_rules()
        ],
    }


@app.get("/rules/{intent}")
def get_rule_for_intent(intent: str):
    tools = rules_db.get_tools_for_intent(intent)

    if not tools:
        raise HTTPException(
            status_code=404,
            detail=f"No rule found for intent '{intent}'",
        )

    rule = rules_db.get_rule(intent)

    if rule is None:
        raise HTTPException(
            status_code=404,
            detail=f"No rule found for intent '{intent}'",
        )

    return {
        "intent": intent,
        "tools": [tool.__dict__ for tool in tools],
        "next_intent_on_fail": rule.next_intent_on_fail,
        "symptoms": rule.symptoms,
        "likely_causes": rule.likely_causes,
        "verification": rule.verification,
    }
```