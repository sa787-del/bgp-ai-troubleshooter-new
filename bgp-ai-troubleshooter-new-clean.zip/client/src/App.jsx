
import { useCallback, useEffect, useMemo, useState } from 'react';
import './App.css';

const API = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000';

const NAV = [
  { id: 'overview', label: 'Overview', icon: '◫', group: 'WORKSPACE' },
  { id: 'lab', label: 'Network Lab', icon: '⌘', group: 'WORKSPACE' },
  { id: 'bgp', label: 'BGP Sessions', icon: '⇄', group: 'COLLECT' },
  { id: 'neighbor', label: 'Peer Details', icon: '◎', group: 'COLLECT' },
  { id: 'routes', label: 'Routing Table', icon: '▤', group: 'COLLECT' },
  { id: 'interfaces', label: 'Interfaces', icon: '⌁', group: 'COLLECT' },
  { id: 'tcp', label: 'TCP Checks', icon: '↔', group: 'COLLECT' },
  { id: 'config', label: 'Configuration', icon: '≋', group: 'COLLECT' },
  { id: 'maps', label: 'Route Maps', icon: '⑂', group: 'COLLECT' },
];

const INFO = {
  overview: ['Operations overview', 'Live collection status for the configured FRR lab devices.'],
  lab: ['Network lab', 'Device inventory and configured peer relationships.'],
  bgp: ['BGP sessions', 'Collect BGP summary and inspect peer state.'],
  neighbor: ['Peer details', 'Inspect detailed neighbor attributes and connection counters.'],
  routes: ['Routing table', 'Search prefixes and inspect paths and best-path attributes.'],
  interfaces: ['Interfaces', 'Inspect interface state and addresses returned by the tool.'],
  tcp: ['TCP checks', 'Test transport reachability to a peer and port.'],
  config: ['Configuration', 'Inspect configuration baseline and drift results.'],
  maps: ['Route maps', 'Inspect route-map entries and match/set clauses.'],
};

function Status({ value }) {
  const text = value == null || value === '' ? 'Not collected' : String(value);
  const s = text.toLowerCase();

  const tone = [
    'established', 'connected', 'success', 'reachable',
    'present', 'up', 'best path',
  ].some(x => s.includes(x))
    ? 'good'
    : [
        'failed', 'error', 'down', 'unreachable', 'disconnected',
      ].some(x => s.includes(x))
      ? 'bad'
      : 'neutral';

  return <span className={`status ${tone}`}><i />{text}</span>;
}

function Metric({ label, value, detail, icon }) {
  return (
    <article className="metric">
      <div className="metric-top">
        <span>{label}</span>
        <b>{icon}</b>
      </div>
      <strong>{value}</strong>
      <small>{detail}</small>
    </article>
  );
}

function Panel({ title, description, action, children }) {
  return (
    <section className="panel">
      <header className="panel-head">
        <div>
          <h2>{title}</h2>
          {description && <p>{description}</p>}
        </div>
        {action}
      </header>
      {children}
    </section>
  );
}

function Empty({
  title = 'No data collected yet',
  detail = 'Run a collection to display data returned by the selected lab router.',
}) {
  return (
    <div className="empty">
      <span>⌁</span>
      <strong>{title}</strong>
      <p>{detail}</p>
    </div>
  );
}

function Field({ label, value }) {
  const shown =
    value == null || value === ''
      ? '—'
      : Array.isArray(value)
        ? value.join(' ') || '—'
        : typeof value === 'object'
          ? JSON.stringify(value)
          : String(value);

  return (
    <div className="field">
      <small>{label.replaceAll('_', ' ')}</small>
      <strong title={shown}>{shown}</strong>
    </div>
  );
}

function Table({ columns, rows, emptyTitle }) {
  if (!rows?.length) {
    return <Empty title={emptyTitle || 'No matching records'} />;
  }

  return (
    <div className="table-scroll">
      <table>
        <thead>
          <tr>
            {columns.map(c => <th key={c.key}>{c.label}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={r.id || r.peer || r.network || r.name || i}>
              {columns.map(c => (
                <td key={c.key}>
                  {c.render
                    ? c.render(r)
                    : r[c.key] == null || r[c.key] === ''
                      ? '—'
                      : String(r[c.key])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Diagnostics({ result }) {
  const [open, setOpen] = useState(false);

  if (!result) return null;

  return (
    <div className="diagnostics">
      <button className="diag-toggle" onClick={() => setOpen(v => !v)}>
        {open ? '− Hide' : '＋ View'} collection diagnostics
      </button>

      {open && (
        <div className="diag-content">
          <small>COMMAND</small>
          <code>{result.command || 'Not provided by API'}</code>

          {result.error && (
            <p className="tool-warning">{result.error}</p>
          )}

          <small>RAW CLI OUTPUT</small>
          <pre>{result.raw_output || 'No raw output returned.'}</pre>

          <small>PARSED PAYLOAD</small>
          <pre>{JSON.stringify(result.parsed ?? result, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [page, setPage] = useState('overview');
  const [devices, setDevices] = useState([]);
  const [deviceId, setDeviceId] = useState('');
  const [inventoryLoading, setInventoryLoading] = useState(true);
  const [apiStatus, setApiStatus] = useState('Checking');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [results, setResults] = useState({});
  const [lastRun, setLastRun] = useState('');

  const [prefix, setPrefix] = useState('');
  const [neighbor, setNeighbor] = useState('');
  const [iface, setIface] = useState('');
  const [targetIp, setTargetIp] = useState('');
  const [tcpPort, setTcpPort] = useState('179');
  const [filter, setFilter] = useState('');

  const device = devices.find(d => d.id === deviceId) || devices[0] || {
    id: '',
    name: 'No device selected',
    host: '127.0.0.1',
    ip: '',
    port: 22,
    asn: '—',
    peer: '',
    rid: '—',
  };

  const resultKey = `${page}:${device.id}`;
  const result = results[resultKey];
  const parsed = result?.parsed || {};

  const call = useCallback(async (path, body, method = 'POST') => {
    let res;

    try {
      res = await fetch(`${API}${path}`, {
        method,
        headers: { 'Content-Type': 'application/json' },
        ...(method === 'GET' ? {} : { body: JSON.stringify(body) }),
      });
    } catch {
      throw new Error(
        'Cannot reach the API. Check that FastAPI is running and VITE_API_BASE is correct.'
      );
    }

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      throw new Error(
        typeof data.detail === 'string'
          ? data.detail
          : `HTTP ${res.status}`
      );
    }

    return data;
  }, []);

  const loadDevices = useCallback(async () => {
    setInventoryLoading(true);

    try {
      const data = await call('/devices', null, 'GET');
      const list = Array.isArray(data.devices) ? data.devices : [];

      setDevices(list);
      setDeviceId(current =>
        list.some(d => d.id === current) ? current : (list[0]?.id || '')
      );

      if (!list.length) {
        setError('No enabled devices found in the backend inventory.');
      }
    } catch (e) {
      setDevices([]);
      setDeviceId('');
      setError(`Could not load device inventory: ${e.message}`);
    } finally {
      setInventoryLoading(false);
    }
  }, [call]);

  const health = useCallback(async () => {
    try {
      const data = await call('/health', null, 'GET');
      setApiStatus(data.status === 'ok' ? 'Connected' : 'Responding');
    } catch {
      setApiStatus('Disconnected');
    }
  }, [call]);

  useEffect(() => {
    health();
    loadDevices();
  }, [health, loadDevices]);

  function save(key, data) {
    setResults(previous => ({ ...previous, [key]: data }));
    setLastRun(new Date().toLocaleTimeString());
  }

  async function collectOverview() {
    if (!devices.length) {
      setError('No devices are configured in the backend inventory.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const pairs = await Promise.all(
        devices.map(async d => {
          try {
            const data = await call('/tools/bgp/state', {
              host: d.host || '127.0.0.1',
              device_port: d.port,
              peer: d.peer || null,
            });

            return [`bgp:${d.id}`, data];
          } catch (e) {
            return [
              `bgp:${d.id}`,
              { success: false, error: e.message, parsed: {} },
            ];
          }
        })
      );

      setResults(previous => ({
        ...previous,
        ...Object.fromEntries(pairs),
      }));

      setLastRun(new Date().toLocaleTimeString());

      if (pairs.every(([, r]) => !r.success)) {
        setError(
          'Collection failed on all devices. Check API logs and SSH access.'
        );
      } else if (pairs.some(([, r]) => !r.success)) {
        setError('At least one device collection failed. Check the results.');
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  async function collect() {
    if (!device.id) {
      setError('No device is selected. Check the backend inventory.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const common = {
        host: device.host || '127.0.0.1',
        device_port: device.port,
      };

      let path;
      let body = common;

      if (page === 'bgp') {
        path = '/tools/bgp/state';
        body = { ...common, peer: device.peer || null };
      } else if (page === 'neighbor') {
        path = '/tools/bgp/neighbor';
        body = {
          ...common,
          peer: (neighbor || device.peer || '').trim(),
        };

        if (!body.peer) {
          throw new Error('Enter a neighbor IP address.');
        }
      } else if (page === 'routes') {
        path = '/tools/route/table';
        if (prefix.trim()) {
          body = { ...common, prefix: prefix.trim() };
        }
      } else if (page === 'interfaces') {
        path = '/tools/interface/detail';
        if (iface.trim()) {
          body = { ...common, interface: iface.trim() };
        }
      } else if (page === 'tcp') {
        const port = Number(tcpPort);

        if (!Number.isInteger(port) || port < 1 || port > 65535) {
          throw new Error('TCP port must be an integer between 1 and 65535.');
        }

        const peerIp = (targetIp || device.peer || '').trim();

        if (!peerIp) {
          throw new Error('Enter a target IP address.');
        }

        path = '/tools/tcp/check';
        body = {
          ...common,
          peer_ip: peerIp,
          port,
        };
      } else if (page === 'config') {
        path = '/tools/config/diff';
      } else if (page === 'maps') {
        path = '/tools/route/map';
      } else {
        throw new Error('Unknown collection tool.');
      }

      const data = await call(path, body);
      save(resultKey, data);

      if (data.success === false) {
        setError(data.error || 'Tool returned an unsuccessful result.');
      }
    } catch (e) {
      setError(`Collection failed: ${e.message}`);
    } finally {
      setLoading(false);
    }
  }

  const bgpEntries = devices
    .map(d => ({ device: d, result: results[`bgp:${d.id}`] }))
    .filter(x => x.result);

  const established = bgpEntries.filter(
    x => String(x.result?.parsed?.queried_peer_state || '')
      .toLowerCase() === 'established'
  ).length;

  const peerCount = bgpEntries.reduce(
    (n, x) => n + Object.keys(x.result?.parsed?.peers || {}).length,
    0
  );

  const paths = Array.isArray(parsed.paths) ? parsed.paths : [];

  const filteredPaths = useMemo(
    () => paths.filter(p =>
      JSON.stringify(p).toLowerCase().includes(filter.toLowerCase())
    ),
    [paths, filter]
  );

  const peers =
    parsed.peers && typeof parsed.peers === 'object'
      ? Object.entries(parsed.peers).map(([ip, value]) =>
          typeof value === 'object' && value !== null
            ? { peer: ip, ...value }
            : { peer: ip, state: value }
        )
      : [];

  const interfaces =
    parsed.interfaces && typeof parsed.interfaces === 'object'
      ? Object.entries(parsed.interfaces).map(([name, value]) => ({
          name,
          ...(typeof value === 'object' && value !== null
            ? value
            : { value }),
        }))
      : Array.isArray(parsed.interfaces)
        ? parsed.interfaces
        : [];

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">N</div>
          <div>
            <strong>NetworkOps</strong>
            <small>BGP TROUBLESHOOTER</small>
          </div>
        </div>

        <div className="workspace">
          <span className="workspace-icon">⌘</span>
          <div>
            <small>WORKSPACE</small>
            <strong>FRR Lab Environment</strong>
            <span>
              {devices.length} configured device{devices.length === 1 ? '' : 's'}
            </span>
          </div>
        </div>

        {['WORKSPACE', 'COLLECT'].map(group => (
          <div className="nav-group" key={group}>
            <p>{group}</p>
            <nav>
              {NAV.filter(n => n.group === group).map(n => (
                <button
                  key={n.id}
                  className={`nav-link ${page === n.id ? 'active' : ''}`}
                  onClick={() => {
                    setPage(n.id);
                    setError('');
                    setFilter('');
                  }}
                >
                  <span className="nav-icon">{n.icon}</span>
                  {n.label}
                  {page === n.id && <i />}
                </button>
              ))}
            </nav>
          </div>
        ))}

        <div className="sidebar-bottom">
          <span className={`pulse ${apiStatus === 'Connected' ? 'on' : ''}`} />
          <div>
            <strong>Backend API</strong>
            <small>{apiStatus}</small>
          </div>
          <small className="lab-label">LOCAL LAB · COLLECT TOOL</small>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="crumb">
            NETWORK OPERATIONS <span>/</span> {INFO[page][0].toUpperCase()}
          </div>

          <div className="top-actions">
            <span className="env"><i /> FRR LAB</span>
            <button className="refresh" title="Check API" onClick={health}>
              ↻
            </button>
            <button
              className="refresh"
              title="Refresh device inventory"
              onClick={loadDevices}
              disabled={inventoryLoading}
            >
              {inventoryLoading ? '…' : '⟳'}
            </button>
            <div className="operator">
              <span>LO</span>
              <div>
                <strong>Lab Operator</strong>
                <small>Local session</small>
              </div>
            </div>
          </div>
        </header>

        <div className="content">
          <section className="page-title">
            <div>
              <p className="eyebrow">{INFO[page][0].toUpperCase()}</p>
              <h1>{INFO[page][0]}</h1>
              <p>{INFO[page][1]}</p>
            </div>

            <div className="page-meta">
              <Status value={apiStatus} />
              <small>
                {lastRun
                  ? `Last collection ${lastRun}`
                  : 'No collection in this session'}
              </small>
            </div>
          </section>

          {error && (
            <div className="alert">
              <b>!</b>
              <div>
                <strong>Collection issue</strong>
                <p>{error}</p>
              </div>
              <button onClick={() => setError('')}>×</button>
            </div>
          )}

          {page === 'overview' && (
            <>
              <div className="metrics">
                <Metric
                  label="Configured devices"
                  value={devices.length}
                  detail="FRR lab inventory"
                  icon="⌘"
                />
                <Metric
                  label="Established sessions"
                  value={bgpEntries.length ? `${established}/${bgpEntries.length}` : '—'}
                  detail="Latest collected peer state"
                  icon="⇄"
                />
                <Metric
                  label="Neighbors discovered"
                  value={bgpEntries.length ? peerCount : '—'}
                  detail="Parsed BGP summary"
                  icon="◎"
                />
                <Metric
                  label="Last collection"
                  value={lastRun || '—'}
                  detail="Browser local time"
                  icon="◷"
                />
              </div>

              <div className="overview-grid">
                <Panel
                  title="Network topology"
                  description="Configured peer relationships between lab devices."
                  action={<Status value={devices.length ? 'Inventory loaded' : 'No devices'} />}
                >
                  {devices.length ? (
                    <div className="topo">
                      {devices.map((d, i) => (
                        <div className="topo-device" key={d.id}>
                          <span className={`router ${i % 2 ? 'green' : ''}`}>
                            {`R${i + 1}`}
                          </span>
                          <div className="topo-info">
                            <strong>{d.name}</strong>
                            <small>
                              AS {d.asn ?? '—'} · {d.ip || d.host}
                            </small>
                            <code>Router ID {d.rid || '—'}</code>
                          </div>
                          <Status
                            value={
                              results[`bgp:${d.id}`]?.parsed?.queried_peer_state
                              || (results[`bgp:${d.id}`]?.success === false
                                ? 'Collection failed'
                                : 'Not collected')
                            }
                          />
                        </div>
                      ))}
                      {devices.length >= 2 && (
                        <div className="peer-link">
                          <span /> Configured peer relationship <span />
                        </div>
                      )}
                    </div>
                  ) : (
                    <Empty
                      title="No devices available"
                      detail="Check the backend device inventory and refresh this page."
                    />
                  )}
                  <div className="panel-foot">
                    Topology displays inventory data; it does not infer live links.
                    <button onClick={() => setPage('lab')}>View lab →</button>
                  </div>
                </Panel>

                <Panel
                  title="Collection center"
                  description="Run a BGP summary query against all configured devices."
                >
                  <div className="callout">
                    <span>⇄</span>
                    <div>
                      <strong>BGP summary collection</strong>
                      <p>Collect current peer state and parsed summary from each device.</p>
                    </div>
                  </div>

                  <button
                    className="primary wide"
                    disabled={loading || inventoryLoading || devices.length === 0}
                    onClick={collectOverview}
                  >
                    {loading ? 'Collecting…' : 'Run collection →'}
                  </button>

                  <div className="readonly">
                    ● Read-only collection · no configuration changes
                  </div>

                  {bgpEntries.length > 0 && (
                    <div className="mini-results">
                      {bgpEntries.map(({ device: d, result: r }) => (
                        <div key={d.id}>
                          <span>{d.name}</span>
                          <Status
                            value={
                              r.success
                                ? r.parsed?.queried_peer_state || 'Collected'
                                : 'Failed'
                            }
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </Panel>
              </div>

              <Panel
                title="Device inventory"
                description="Endpoints used by collection tools."
                action={
                  <button
                    className="link-button"
                    onClick={() => setPage('lab')}
                  >
                    View network lab →
                  </button>
                }
              >
                <Table
                  rows={devices}
                  emptyTitle={inventoryLoading ? 'Loading device inventory' : 'No devices configured'}
                  columns={[
                    { key: 'name', label: 'DEVICE', render: r => <strong>{r.name}</strong> },
                    { key: 'ip', label: 'DEVICE IP', render: r => <code>{r.ip || r.host}</code> },
                    { key: 'port', label: 'SSH PORT', render: r => <code>{r.port}</code> },
                    { key: 'asn', label: 'LOCAL AS', render: r => <code>{r.asn ?? '—'}</code> },
                    { key: 'peer', label: 'BGP PEER', render: r => <code>{r.peer || '—'}</code> },
                    {
                      key: 'state',
                      label: 'LAST OBSERVED STATE',
                      render: r => (
                        <Status
                          value={
                            results[`bgp:${r.id}`]?.parsed?.queried_peer_state
                            || (results[`bgp:${r.id}`]?.success === false
                              ? 'Collection failed'
                              : 'Not collected')
                          }
                        />
                      ),
                    },
                  ]}
                />
              </Panel>
            </>
          )}

          {page === 'lab' && (
            <>
              <div className="metrics three">
                <Metric
                  label="Configured devices"
                  value={devices.length}
                  detail="FRR SSH endpoints"
                  icon="⌘"
                />
                <Metric
                  label="Autonomous systems"
                  value={new Set(devices.map(d => d.asn).filter(v => v != null)).size}
                  detail="Distinct AS numbers in inventory"
                  icon="◎"
                />
                <Metric
                  label="Peer relationships"
                  value={devices.filter(d => d.peer).length}
                  detail="Devices with a configured peer"
                  icon="⇄"
                />
              </div>

              <Panel
                title="Router inventory"
                description="These are configured FRR lab endpoints, not physical HPE switches."
                action={
                  <button
                    className="link-button"
                    onClick={loadDevices}
                    disabled={inventoryLoading}
                  >
                    {inventoryLoading ? 'Refreshing…' : 'Refresh inventory ↻'}
                  </button>
                }
              >
                <Table
                  rows={devices}
                  emptyTitle={inventoryLoading ? 'Loading device inventory' : 'No devices configured'}
                  columns={[
                    { key: 'name', label: 'DEVICE', render: r => <strong>{r.name}</strong> },
                    { key: 'ip', label: 'ROUTER IP', render: r => <code>{r.ip || r.host}</code> },
                    { key: 'port', label: 'SSH PORT', render: r => <code>{r.port}</code> },
                    { key: 'asn', label: 'LOCAL AS', render: r => <code>{r.asn ?? '—'}</code> },
                    { key: 'rid', label: 'ROUTER ID', render: r => <code>{r.rid || '—'}</code> },
                    { key: 'peer', label: 'PEER IP', render: r => <code>{r.peer || '—'}</code> },
                  ]}
                />
              </Panel>

              <Panel
                title="Peer relationship"
                description="The inventory supplies peer values; collection determines observed session state."
              >
                {devices.length >= 2 ? (
                  <div className="peer-card">
                    <div>
                      <span className="router">R1</span>
                      <strong>AS {devices[0].asn ?? '—'}</strong>
                      <small>{devices[0].ip || devices[0].host}</small>
                    </div>
                    <div className="connection">
                      <span />
                      <b>Configured peer</b>
                      <small>{devices[0].peer || 'Peer not specified'}</small>
                      <span />
                    </div>
                    <div>
                      <span className="router green">R2</span>
                      <strong>AS {devices[1].asn ?? '—'}</strong>
                      <small>{devices[1].ip || devices[1].host}</small>
                    </div>
                  </div>
                ) : (
                  <Empty
                    title="At least two devices are needed"
                    detail="Add a second enabled device to the backend inventory to display a peer relationship."
                  />
                )}

                <button
                  className="primary"
                  onClick={collectOverview}
                  disabled={loading || inventoryLoading || devices.length === 0}
                >
                  {loading ? 'Collecting…' : 'Collect peer state'}
                </button>
              </Panel>
            </>
          )}

          {['bgp', 'neighbor', 'routes', 'interfaces', 'tcp', 'config', 'maps'].includes(page) && (
            <>
              <Panel
                title="Collection parameters"
                description="Select a router and run its corresponding backend tool."
              >
                <div className="form-grid">
                  <label>
                    Target router
                    <select
                      value={deviceId}
                      onChange={e => {
                        setDeviceId(e.target.value);
                        setError('');
                      }}
                      disabled={loading || inventoryLoading || devices.length === 0}
                    >
                      {devices.map(d => (
                        <option key={d.id} value={d.id}>
                          {d.name} · {d.ip || d.host}:{d.port}
                        </option>
                      ))}
                    </select>
                  </label>

                  {page === 'routes' && (
                    <label>
                      Prefix filter
                      <input
                        value={prefix}
                        onChange={e => setPrefix(e.target.value)}
                        placeholder="e.g. 10.2.2.2/32 (optional)"
                      />
                    </label>
                  )}

                  {page === 'neighbor' && (
                    <label>
                      Neighbor IP
                      <input
                        value={neighbor}
                        onChange={e => setNeighbor(e.target.value)}
                        placeholder={device.peer || 'Enter neighbor IP'}
                      />
                    </label>
                  )}

                  {page === 'interfaces' && (
                    <label>
                      Interface name
                      <input
                        value={iface}
                        onChange={e => setIface(e.target.value)}
                        placeholder="Blank = all interfaces"
                      />
                    </label>
                  )}

                  {page === 'tcp' && (
                    <>
                      <label>
                        Target IP
                        <input
                          value={targetIp}
                          onChange={e => setTargetIp(e.target.value)}
                          placeholder={device.peer || 'Enter target IP'}
                        />
                      </label>
                      <label>
                        TCP port
                        <input
                          type="number"
                          min="1"
                          max="65535"
                          value={tcpPort}
                          onChange={e => setTcpPort(e.target.value)}
                        />
                      </label>
                    </>
                  )}

                  <div className="form-action">
                    <button
                      className="primary"
                      onClick={collect}
                      disabled={loading || inventoryLoading || devices.length === 0}
                    >
                      {loading ? 'Collecting…' : 'Run collection →'}
                    </button>
                  </div>
                </div>

                <div className="form-note">
                  ⓘ Requests are sent to the FastAPI backend. No configuration changes are made.
                  {inventoryLoading && ' Loading device inventory…'}
                  {!inventoryLoading && devices.length === 0 && ' No devices are available; check the API inventory.'}
                </div>
              </Panel>

              {result ? (
                <>
                  <div className="result-banner">
                    <div>
                      <span>{result.success === false ? '!' : '✓'}</span>
                      <div>
                        <strong>
                          {result.success === false
                            ? 'Tool reported a failure'
                            : 'Collection response received'}
                        </strong>
                        <small>
                          {result.command || 'Response received from backend'}
                          {lastRun ? ` · ${lastRun}` : ''}
                        </small>
                      </div>
                    </div>
                    <Status value={result.success === false ? 'Failed' : 'Received'} />
                  </div>

                  {page === 'bgp' && (
                    <>
                      <div className="metrics three">
                        <Metric label="Parsed peer records" value={peers.length} detail="BGP summary parser" icon="◎" />
                        <Metric label="Queried peer state" value={parsed.queried_peer_state || '—'} detail={device.peer || 'Peer not configured'} icon="⇄" />
                        <Metric label="Tool result" value={result.success === false ? 'Failed' : 'Returned'} detail="Backend response" icon="✓" />
                      </div>

                      <Panel
                        title="BGP neighbors"
                        description="Parsed peer records from the selected router."
                      >
                        <Table
                          rows={peers}
                          columns={[
                            { key: 'peer', label: 'NEIGHBOR', render: r => <code>{r.peer || r.ip || '—'}</code> },
                            { key: 'state', label: 'STATE', render: r => <Status value={r.state || r.peer_state || r.bgp_state} /> },
                            { key: 'asn', label: 'PEER AS', render: r => r.asn ?? r.remote_as ?? r.peer_as ?? '—' },
                            { key: 'prefixes_received', label: 'PREFIXES RECEIVED' },
                          ]}
                        />
                      </Panel>

                      <Panel title="Queried peer state">
                        <div className="detail-grid">
                          <Field label="Router" value={device.name} />
                          <Field label="Neighbor" value={device.peer} />
                          <Field label="State" value={parsed.queried_peer_state} />
                          <Field label="State reason" value={parsed.queried_peer_state_reason} />
                        </div>
                      </Panel>
                    </>
                  )}

                  {page === 'neighbor' && (
                    <Panel
                      title="Neighbor attributes"
                      description="Only fields present in the returned parser payload are shown."
                    >
                      <div className="detail-grid">
                        {[
                          'remote_as', 'local_as', 'state', 'admin_shutdown',
                          'hostname', 'remote_router_id', 'local_host',
                          'last_reset', 'hold_time', 'connections_established',
                          'connections_dropped', 'notification', 'peer_open_as',
                        ]
                          .filter(k => parsed[k] !== undefined)
                          .map(k => <Field key={k} label={k} value={parsed[k]} />)}
                      </div>
                      {!Object.keys(parsed).length && <Empty title="No parsed neighbor attributes" />}
                    </Panel>
                  )}

                  {page === 'routes' && (
                    <>
                      <div className="metrics three">
                        <Metric label="Prefix" value={parsed.prefix || prefix || 'Full table'} detail={parsed.in_table === true ? 'Present in BGP table' : parsed.in_table === false ? 'Not found' : 'Query response'} icon="▤" />
                        <Metric label="Available paths" value={parsed.path_count ?? paths.length} detail="Parsed path records" icon="⇄" />
                        <Metric label="Best path" value={parsed.best_path ? 'Selected' : '—'} detail="Returned by route parser" icon="✓" />
                      </div>

                      {parsed.best_path && (
                        <Panel
                          title="Best path details"
                          description="Selected route attributes returned by the backend."
                        >
                          <div className="detail-grid">
                            {[
                              'network', 'next_hop', 'metric', 'local_pref',
                              'weight', 'as_path', 'as_path_length', 'origin',
                              'from_peer', 'best_reason',
                            ].map(k => (
                              <Field key={k} label={k} value={parsed.best_path[k]} />
                            ))}
                          </div>
                        </Panel>
                      )}

                      <Panel
                        title="Available paths"
                        description={`${filteredPaths.length} matching path(s)`}
                        action={
                          <input
                            className="search"
                            value={filter}
                            onChange={e => setFilter(e.target.value)}
                            placeholder="Filter paths…"
                          />
                        }
                      >
                        <Table
                          rows={filteredPaths}
                          columns={[
                            { key: 'network', label: 'NETWORK', render: r => <code>{r.network}</code> },
                            { key: 'next_hop', label: 'NEXT HOP', render: r => <code>{r.next_hop}</code> },
                            { key: 'as_path', label: 'AS PATH', render: r => <code>{Array.isArray(r.as_path) ? r.as_path.join(' ') || '—' : r.as_path || '—'}</code> },
                            { key: 'metric', label: 'METRIC' },
                            { key: 'weight', label: 'WEIGHT' },
                            { key: 'origin', label: 'ORIGIN' },
                            { key: 'is_best', label: 'STATUS', render: r => <Status value={r.is_best ? 'Best path' : 'Available'} /> },
                          ]}
                        />
                      </Panel>
                    </>
                  )}

                  {page === 'interfaces' && (
                    <Panel
                      title="Interface inventory"
                      description="Parsed interface state and address fields."
                    >
                      <Table
                        rows={interfaces}
                        columns={[
                          { key: 'name', label: 'INTERFACE', render: r => <code>{r.name || r.interface || '—'}</code> },
                          { key: 'link_state', label: 'LINK STATE', render: r => <Status value={r.link_state} /> },
                          { key: 'admin_state', label: 'ADMIN STATE', render: r => <Status value={r.admin_state} /> },
                          { key: 'ip_address', label: 'IP ADDRESS', render: r => <code>{r.ip_address || '—'}</code> },
                        ]}
                      />
                    </Panel>
                  )}

                  {page === 'tcp' && (
                    <Panel
                      title="TCP reachability"
                      description="Transport connectivity is not, by itself, proof that a BGP session is established."
                    >
                      <div className="detail-grid">
                        <Field label="Target IP" value={targetIp || device.peer} />
                        <Field label="TCP port" value={tcpPort} />
                        <Field label="Tool success" value={result.success} />
                        {Object.entries(parsed).map(([k, v]) => (
                          <Field key={k} label={k} value={v} />
                        ))}
                      </div>
                    </Panel>
                  )}

                  {page === 'config' && (
                    <Panel
                      title="Configuration drift"
                      description="Baseline and difference fields returned by the config tool."
                    >
                      <div className="detail-grid">
                        <Field label="Baseline available" value={parsed.has_baseline} />
                        <Field label="Drift detected" value={parsed.drifted} />
                        <Field label="Tool success" value={result.success} />
                      </div>
                      {parsed.diff && (
                        <pre className="output">
                          {typeof parsed.diff === 'string'
                            ? parsed.diff
                            : JSON.stringify(parsed.diff, null, 2)}
                        </pre>
                      )}
                    </Panel>
                  )}

                  {page === 'maps' && (
                    <Panel
                      title="Route-map data"
                      description="Parsed route-map response from the backend."
                    >
                      <pre className="output">{JSON.stringify(parsed, null, 2)}</pre>
                    </Panel>
                  )}

                  <Panel
                    title="Collection diagnostics"
                    description="Evidence for debugging and mentor review."
                  >
                    <Diagnostics result={result} />
                  </Panel>
                </>
              ) : (
                <Empty
                  title="Ready to collect"
                  detail="Choose the router and run collection. Results appear here only after the backend responds."
                />
              )}
            </>
          )}

          <footer className="footer">
            <span>NetworkOps · BGP AI Troubleshooter</span>
            <span>FRR lab · Collection interface</span>
          </footer>
        </div>
      </main>
    </div>
  );
}
