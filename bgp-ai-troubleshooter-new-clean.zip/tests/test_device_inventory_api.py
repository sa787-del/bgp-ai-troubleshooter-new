
from fastapi.testclient import TestClient

from api import main


class FakeResult:
    def to_dict(self):
        return {
            "tool_id": "interface",
            "host": "127.0.0.1",
            "command": "show interface eth1",
            "success": True,
            "raw_output": "Interface eth1 is up",
            "parsed": {
                "interfaces": {
                    "eth1": {"link_state": "up"}
                }
            },
            "error": None,
        }


class FakeTool:
    def run(self, host, *args):
        return FakeResult()


client = TestClient(main.app)


def test_health_endpoint():
    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_device_inventory_endpoint():
    response = client.get("/devices")

    assert response.status_code == 200

    devices = response.json()["devices"]
    assert isinstance(devices, list)
    assert {device["id"] for device in devices} >= {"r1", "r2"}


def test_interface_accepts_interface_name(monkeypatch):
    monkeypatch.setattr(
        main,
        "make_tool",
        lambda *args, **kwargs: FakeTool(),
    )

    response = client.post(
        "/tools/interface/detail",
        json={
            "host": "127.0.0.1",
            "device_port": 2221,
            "interface_name": "eth1",
        },
    )

    assert response.status_code == 200
    assert response.json()["success"] is True


def test_interface_accepts_interface(monkeypatch):
    monkeypatch.setattr(
        main,
        "make_tool",
        lambda *args, **kwargs: FakeTool(),
    )

    response = client.post(
        "/tools/interface/detail",
        json={
            "host": "127.0.0.1",
            "device_port": 2221,
            "interface": "eth1",
        },
    )

    assert response.status_code == 200
    assert response.json()["success"] is True


def test_unknown_target_is_rejected():
    response = client.post(
        "/tools/bgp/state",
        json={
            "host": "192.0.2.99",
            "device_port": 2221,
        },
    )

    assert response.status_code == 400
