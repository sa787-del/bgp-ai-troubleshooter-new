
from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class DeviceResult:
    host: str
    command: str
    success: bool
    output: str = ""
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ToolResult:
    host: str
    tool_id: str
    success: bool
    raw_output: str = ""
    parsed: dict[str, Any] = field(default_factory=dict)
    error: str | None = None
    command: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class BaseTool:
    tool_id = "base"

    def __init__(self, device_client=None):
        self.device_client = device_client

    def _wrap(self, host, device_result, parsed=None):
        return ToolResult(
            host=host,
            tool_id=self.tool_id,
            success=bool(device_result.success),
            raw_output=device_result.output or "",
            parsed=parsed or {},
            error=device_result.error,
            command=device_result.command,
        )
