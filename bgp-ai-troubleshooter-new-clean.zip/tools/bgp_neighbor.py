
"""
Tool 5: BGP Neighbor

Purpose:
- Run `show bgp neighbors <peer>`.
- Parse local and remote AS numbers, BGP state, admin shutdown,
  router ID, connection counters, last reset and notifications.
- On an OPEN Message Error, attempt to extract the peer's AS
  from the captured OPEN message.
"""

import re
from typing import Optional

from tools.base import BaseTool, ToolResult


HEADER_RE = re.compile(
    r"BGP neighbor is (?P<peer>\S+), remote AS (?P<remote_as>\d+), "
    r"local AS (?P<local_as>\d+), (?P<link>\w+) link"
)

STATE_RE = re.compile(r"BGP state = (?P<state>\w+)")
HOSTNAME_RE = re.compile(r"^Hostname: (?P<name>\S+)", re.MULTILINE)
ROUTER_ID_RE = re.compile(r"remote router ID (?P<id>[\d.]+)")
CONNECTIONS_RE = re.compile(
    r"Connections established (?P<up>\d+); dropped (?P<dropped>\d+)"
)
LAST_RESET_RE = re.compile(r"Last reset \S+,\s+(?P<reason>.+)")
NOTIFICATION_RE = re.compile(
    r"Notification (?P<direction>sent|received) \((?P<error>[^)]+)\)"
)
LOCAL_HOST_RE = re.compile(r"^Local host: (?P<ip>[\d.]+)", re.MULTILINE)
HOLD_TIME_RE = re.compile(r"Hold time is (?P<hold>\d+)")
HEX_RE = re.compile(r"^\s*(?:[0-9A-Fa-f]{2,8}\s*)+$")

AS_TRANS = 23456
CAP_4BYTE_AS = 65


class BGPNeighborTool(BaseTool):
    tool_id = "bgp_neighbor"

    def __init__(self, device_client=None):
        super().__init__(device_client=device_client)

    def run(
        self,
        host: str,
        peer: str,
        port: Optional[int] = None,
    ) -> ToolResult:
        """Collect and parse details for one BGP neighbor."""
        result = self.device_client.run_vtysh(
            host,
            f"show bgp neighbors {peer}",
            port=port,
        )

        parsed = self._parse(result.output or "")
        return self._wrap(host, result, parsed)

    def _parse(self, output: str) -> dict:
        """Parse BGP neighbor information from FRR command output."""
        header = HEADER_RE.search(output)

        if not header:
            return {
                "configured": False,
                "peer": None,
                "reason": "Neighbor was not found in the command output.",
            }

        last_reset = _group(LAST_RESET_RE, output, "reason")

        parsed = {
            "configured": True,
            "peer": header["peer"],
            "remote_as": int(header["remote_as"]),
            "local_as": int(header["local_as"]),
            "link": header["link"],
            "state": _group(STATE_RE, output, "state"),
            "admin_shutdown": "Administratively shut down" in output,
            "hostname": _group(HOSTNAME_RE, output, "name"),
            "remote_router_id": _group(ROUTER_ID_RE, output, "id"),
            "local_host": _group(LOCAL_HOST_RE, output, "ip"),
            "last_reset": last_reset,
            "hold_time": _int(_group(HOLD_TIME_RE, output, "hold")),
            "notification": None,
            "peer_open_as": None,
        }

        connections = CONNECTIONS_RE.search(output)
        if connections:
            parsed["connections_established"] = int(connections["up"])
            parsed["connections_dropped"] = int(connections["dropped"])

        notification_text = last_reset or ""
        note = NOTIFICATION_RE.search(notification_text)

        if note:
            parsed["notification"] = {
                "direction": note["direction"],
                "error": note["error"],
            }

            # Only inspect the OPEN dump when the latest reset indicates
            # an OPEN Message Error sent by this router.
            if (
                note["direction"] == "sent"
                and note["error"].startswith("OPEN Message Error")
            ):
                parsed["peer_open_as"] = _open_as(output)

        return parsed


def _group(
    regex: re.Pattern,
    text: str,
    name: str,
) -> Optional[str]:
    match = regex.search(text)
    return match[name] if match else None


def _int(text: Optional[str]) -> Optional[int]:
    return int(text) if text else None


def _open_as(output: str) -> Optional[int]:
    """
    Extract the remote AS from a captured BGP OPEN message.

    If the two-byte AS field is AS_TRANS, look for the four-byte
    AS capability (code 65).
    """
    marker = "Message received that caused BGP to send a NOTIFICATION:"
    _, separator, dump = output.partition(marker)

    if not separator:
        return None

    hex_parts = []

    for line in dump.splitlines()[1:]:
        if not HEX_RE.match(line):
            break
        hex_parts.append("".join(line.split()))

    if not hex_parts:
        return None

    try:
        message = bytes.fromhex("".join(hex_parts))
    except ValueError:
        return None

    # BGP header: 16-byte marker, 2-byte length, 1-byte message type.
    # OPEN message type is 1.
    if len(message) < 29 or message[18] != 1:
        return None

    asn = int.from_bytes(message[20:22], "big")

    if asn != AS_TRANS:
        return asn

    # OPEN fixed header:
    # 19-byte BGP header + 10-byte OPEN fixed fields.
    optional_length = message[28]
    params = message[29:29 + optional_length]

    if len(params) != optional_length:
        return None

    index = 0

    while index + 2 <= len(params):
        parameter_type = params[index]
        parameter_length = params[index + 1]
        parameter_end = index + 2 + parameter_length

        if parameter_end > len(params):
            return None

        parameter_data = params[index + 2:parameter_end]

        # Optional parameter type 2 contains capabilities.
        if parameter_type == 2:
            cap_index = 0

            while cap_index + 2 <= len(parameter_data):
                capability_code = parameter_data[cap_index]
                capability_length = parameter_data[cap_index + 1]
                capability_end = cap_index + 2 + capability_length

                if capability_end > len(parameter_data):
                    break

                if (
                    capability_code == CAP_4BYTE_AS
                    and capability_length == 4
                ):
                    return int.from_bytes(
                        parameter_data[cap_index + 2:capability_end],
                        "big",
                    )

                cap_index = capability_end

        index = parameter_end

    return None
