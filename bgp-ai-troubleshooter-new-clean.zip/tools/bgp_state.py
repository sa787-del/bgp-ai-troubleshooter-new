
"""
Collect BGP neighbor states using:
    show bgp summary
"""

import re

from tools.base import BaseTool, ToolResult
from tools.device_client import FRRDeviceClient


IPV4_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")


class BGPStateTool(BaseTool):
    tool_id = "bgp_state"

    def __init__(self, device_client=None):
        super().__init__(device_client=device_client)
        self.device_client = device_client or FRRDeviceClient()

    def run(
        self,
        host: str,
        peer: str | None = None,
        port: int | None = None,
    ) -> ToolResult:
        result = self.device_client.run_vtysh(
            host,
            "show bgp summary",
            port=port,
        )

        parsed = self._parse(result.output or "", peer)

        return self._wrap(host, result, parsed)

    def _parse(
        self,
        output: str,
        peer: str | None = None,
    ) -> dict:
        peers = {}
        state_reasons = {}

        for line in output.splitlines():
            fields = line.split()

            # FRR neighbor rows start with a neighbor IP.
            if len(fields) < 10 or not IPV4_RE.match(fields[0]):
                continue

            neighbor = fields[0]
            state_field = fields[9]
            extra_field = fields[10] if len(fields) > 10 else ""

            if state_field.isdigit():
                # A number in State/PfxRcd means the session is up.
                state = "Established"

            elif state_field == "(Policy)":
                state = "Established"
                state_reasons[neighbor] = "Policy"

            elif state_field in {
                "Active",
                "Connect",
                "Idle",
                "OpenSent",
                "OpenConfirm",
            }:
                state = state_field

                # FRR may print reasons separately, e.g. Idle (Admin).
                if extra_field.startswith("(") and extra_field.endswith(")"):
                    state_reasons[neighbor] = extra_field.strip("()")

            elif state_field.startswith("Idle"):
                # Handles formats such as Idle(Admin).
                state = "Idle"
                reason = state_field[len("Idle"):].strip(" ()")
                if reason:
                    state_reasons[neighbor] = reason

            else:
                # Preserve unfamiliar state text rather than hiding it.
                state = state_field

            peers[neighbor] = state

        parsed = {
            "peers": peers,
            "state_reasons": state_reasons,
        }

        if peer:
            parsed["queried_peer_state"] = peers.get(peer, "unknown")
            parsed["queried_peer_state_reason"] = state_reasons.get(peer)

        return parsed
