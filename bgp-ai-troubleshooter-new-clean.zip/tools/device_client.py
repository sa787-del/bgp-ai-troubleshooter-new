
import os
from dataclasses import dataclass
from typing import Optional

import paramiko


@dataclass
class DeviceResult:
    host: str
    command: str
    success: bool
    output: str
    error: Optional[str] = None


class FRRDeviceClient:
    def __init__(
        self,
        username="admin",
        password="admin",
        port=None,
        timeout=8,
    ):
        self.username = username
        self.password = password
        self.port = (
            port
            if port is not None
            else int(os.getenv("FRR_SSH_PORT", "22"))
        )
        self.timeout = timeout

    def run_vtysh(self, host, command, port=None):
        quoted_command = self._quote(command)
        full_command = f"vtysh -c {quoted_command}"

        return self._run(
            host,
            full_command,
            display_command=command,
            port=port,
        )

    def run_raw(self, host, command, port=None):
        return self._run(
            host,
            command,
            display_command=command,
            port=port,
        )

    def _run(self, host, shell_command, display_command, port=None):
        ssh_port = port if port is not None else self.port
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(
            paramiko.AutoAddPolicy()
        )

        try:
            client.connect(
                hostname=host,
                port=ssh_port,
                username=self.username,
                password=self.password,
                timeout=self.timeout,
                banner_timeout=self.timeout,
                auth_timeout=self.timeout,
                look_for_keys=False,
                allow_agent=False,
            )

            _, stdout, stderr = client.exec_command(shell_command)

            output = stdout.read().decode(
                "utf-8", errors="replace"
            ).strip()

            error = stderr.read().decode(
                "utf-8", errors="replace"
            ).strip()

            exit_code = stdout.channel.recv_exit_status()

            return DeviceResult(
                host=host,
                command=display_command,
                success=(exit_code == 0),
                output=output,
                error=error or None,
            )

        except Exception as exc:
            return DeviceResult(
                host=host,
                command=display_command,
                success=False,
                output="",
                error=str(exc),
            )

        finally:
            client.close()

    @staticmethod
    def _quote(value):
        return "'" + value.replace("'", "'\\''") + "'"
